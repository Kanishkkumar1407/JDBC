package jdbc;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
public class JDBCDemo1 {

	public static void main(String[] args)  throws Exception
	{
		// 1.Loading a Driver class
		Class.forName("com.mysql.cj.jdbc.Driver");
		System.out.println("Driver class loaded onto memory");
		// 2.Establishing a connection
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/kanishk","root","tiger");
		System.out.println("Connection is established with mysql");
		// 3. Create a statement object
		Statement st=con.createStatement();
		String query="insert into student values('61','sanjay','amberpet','142');";
		st.execute(query);
		System.out.println("record inserted");
		con.close();
		System.out.println("Connection is released");
		
		}
}
