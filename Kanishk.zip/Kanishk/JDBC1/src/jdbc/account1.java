package jdbc;
import java.sql.*;
import java.util.Scanner;
public class account1 {
    public static void main(String[] args) throws Exception {
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/kanishk", "root", "tiger");
        Statement stmt = con.createStatement();
        Scanner scan = new Scanner(System.in);

        stmt.executeUpdate("create table IF NOT EXISTS atm(accno INT,pass varchar(50),name varchar(50),balance INT,bank_name varchar(10));");

        boolean loop = true;
        while (loop) {
            System.out.println("Enter your choice\n1. Create a new account\n2. Withdraw\n3. Deposit\n4. Balance Enquiry\n5. Exit\n");
            int ch = scan.nextInt();
            switch (ch) {
                case 1:
                    System.out.println("Enter your account number");
                    double accno = scan.nextDouble();
                    System.out.println("Enter your account Password");
                    int pass = scan.nextInt();
                    System.out.println("Enter account name");
                    String name = scan.next();
                    int balance = 500;
                    System.out.println("Enter bank name");
                    String bank_name = scan.next();
                    String insertQuery = "insert into atm values(" + accno + ',' + pass + ',' + "'" + name + "'" + ',' + balance + ",'" + bank_name + "')";
                    stmt.executeUpdate(insertQuery);
                    System.out.println("Account created successfully!");
                    break;

                case 2:
                    System.out.println("Enter account number");
                    double acc = scan.nextDouble();
                    ResultSet rs = stmt.executeQuery("select * from atm where accno=" + acc);
                    System.out.println("Enter password");
                    int password = scan.nextInt();

                    if (rs.next() && password == rs.getInt("pass")) {
                        double currentBalance = rs.getDouble("balance");
                        if (currentBalance > 0) {
                            System.out.println("Enter amount to withdraw");
                            int amt = scan.nextInt();
                            if (amt >= 0 && amt <= currentBalance) {
                                double newBal = currentBalance - amt;
                                stmt.executeUpdate("update atm set balance = " + newBal + " where accno = " + acc);
                                System.out.println("Withdrawal successful. Current balance: " + newBal);
                            } else {
                                System.out.println("Invalid withdrawal amount.");
                            }
                        } else {
                            System.out.println("Insufficient balance.");
                        }
                    } else {
                        System.out.println("Invalid account number or password.");
                    }
                    break;

                case 3:
                    System.out.println("Enter account number");
                    double deposit = scan.nextDouble();
                    ResultSet rsDeposit = stmt.executeQuery("select * from atm where accno=" + deposit);
                    System.out.println("Enter password");
                    int pd = scan.nextInt();

                    if (rsDeposit.next() && pd == rsDeposit.getInt("pass")) {
                        System.out.println("Enter amount to deposit");
                        int dAmt = scan.nextInt();
                        if (dAmt >= 0) {
                            double newBal = rsDeposit.getDouble("balance") + dAmt;
                            stmt.executeUpdate("update atm set balance = " + newBal + " where accno = " + deposit);
                            System.out.println("Deposit successful. Current balance: " + newBal);
                        } else {
                            System.out.println("Invalid deposit amount.");
                        }
                    } else {
                        System.out.println("Invalid account number or password.");
                    }
                    break;

                case 4:
                    System.out.println("Enter account number");
                    double accBalance = scan.nextDouble();
                    ResultSet rsBalance = stmt.executeQuery("select * from atm where accno=" + accBalance);
                    System.out.println("Enter password");
                    int passBal = scan.nextInt();

                    if (rsBalance.next() && passBal == rsBalance.getInt("pass")) {
                        double currentBalance = rsBalance.getDouble("balance");
                        System.out.println("Your current balance: " + currentBalance);
                    } else {
                        System.out.println("Invalid account number or password.");
                    }
                    break;

                case 5:
                    System.out.println("Exiting");
                    loop = false;
                    break;

                default:
                    System.out.println("Invalid choice");
            }
        }
        con.close();
        stmt.close();
        scan.close();
    }
}
