package jdbc;
import java.sql.*;
import java.util.Scanner;
import java.sql.PreparedStatement;
import java.sql.DriverManager;
public class db1 {
	public static void main(String[] args) throws Exception {
		Class.forName("com.mysql.cj.jdbc.Driver");
		System.out.println("Driver Loaded");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/kanishk","root","tiger");
		System.out.println("Connection Established");
		Scanner s = new Scanner(System.in);
		System.out.println("1.Insert\n2.Update\n3.Delete\n4.Select");
		int t =1;
		while(t==1) {
			System.out.println("Enter your choice");
			int i = s.nextInt();
			switch(i)
			{
			case 1:
				System.out.println("Enter student id: ");
				int stdid=s.nextInt();
				System.out.println("Enter student name");
				String stdname=s.next();
				System.out.println("Enter student marks1");
				int m1=s.nextInt();
				System.out.println("Enter student marks2");
      			int m2=s.nextInt();
				System.out.println("Enter student marks3");
				int m3=s.nextInt();
				System.out.println("Enter student marks4");
				int m4=s.nextInt();
				System.out.println("Enter student marks5");
				int m5=s.nextInt();
				System.out.println("Enter student marks6");
				int m6=s.nextInt();
				if(m1>=0&&m1<=100&&m2>=0&&m2<=100&&m3>=0&&m3<=100&&m4>=0&&m4<=100&&m5>=0& m5<=100&&m6>=0&&m6<=100) {
				PreparedStatement p=con.prepareStatement("insert into student2 values(?,?,?,?,?,?,?,?)");
				p.setInt(1,stdid);
				p.setString(2,stdname);
				p.setInt(3,m1);
				p.setInt(4,m2);
				p.setInt(5,m3);
				p.setInt(6,m4);
				p.setInt(7,m5);
				p.setInt(8,m6);
				p.executeUpdate();
				System.out.println("Student Data Entered Successfully");
				}
				else {
					System.out.println("Marks should be between 0 to 100");
				}
				break;
			case 2:
				System.out.println("Enter student id to update:");
				int sid=s.nextInt();
				System.out.println("Enter which subject number (1,2,3,4,5,6)should be updated");
				int sub=s.nextInt();
				System.out.println("Enter updated marks");
				int nm=s.nextInt();
				if(nm>=0&&nm<=100) {
				if (sub==1) {
					PreparedStatement p1=con.prepareStatement("update student2 set m1 =? where studentid=?");
					p1.setInt(1,nm);
					p1.setInt(2,sid);
					p1.executeUpdate();
				}
				if (sub==2) {
					PreparedStatement p1=con.prepareStatement("update student2 set m2 =? where studentid=?");
					p1.setInt(1,nm);
					p1.setInt(2,sid);			
					p1.executeUpdate();
				}
				if (sub==3) {
					PreparedStatement p1=con.prepareStatement("update student2 set m3 =? where studentid=?");
					p1.setInt(1,nm);
					p1.setInt(2,sid);
					p1.executeUpdate();
				}
				if (sub==5) {
					PreparedStatement p1=con.prepareStatement("update student2 set m5 =? where studentid=?");
					p1.setInt(1,nm);
					p1.setInt(2,sid);
					p1.executeUpdate();

				}
				if (sub==6) {
					PreparedStatement p1=con.prepareStatement("update student2 set m6 =? where studentid=?");
					p1.setInt(1,nm);
					p1.setInt(2,sid);
					p1.executeUpdate();
				}
				if (sub==4) {
					PreparedStatement p1=con.prepareStatement("update student2 set m4 =? where studentid=?");
					p1.setInt(1,nm);
					p1.setInt(2,sid);
					p1.executeUpdate();
				}

				}
				else {
					System.out.println("Marks should be 0 to 100");
				}
				System.out.println("Records Updated");
				break;
			case 3:
				System.out.print("Enter student id to delete");
				int did=s.nextInt();
				PreparedStatement p2=con.prepareStatement("delete from student2 where studentid=?");
				p2.setInt(1, did);
				p2.executeUpdate();
				System.out.println("Records Updated");
				break;
			case 4:
				System.out.println("Enter student id that to be displayed");
				int rid = s.nextInt();
				PreparedStatement r = con.prepareStatement("select * from student2 where studentid=?");
				r.setInt(1, rid);
				ResultSet rs = r.executeQuery();
				while(rs.next())
				{
					System.out.println("ID:"+rs.getInt(1));
					System.out.println("Name:"+rs.getString(2));
					System.out.println("Marks1:"+rs.getInt(3));
					System.out.println("Marks2:"+rs.getInt(4));
					System.out.println("Marks3:"+rs.getInt(5));
					System.out.println("Marks4:"+rs.getInt(6));
					System.out.println("Marks5:"+rs.getInt(7));
					System.out.println("Marks6:"+rs.getInt(8));
				}
				break;
			default :
				System.out.println("Invalid Choice");
		}
			System.out.println("Do you want to continue the process?");
			System.out.println("If Yes Click 1");
			System.out.println("If No Click 0");
			t = s.nextInt();		
		}
		con.close();


	}



}