package jdbc;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.*;
public class employee1  {
	public static void main(String[] args) throws Exception{
				Scanner sc = new Scanner(System.in);
				Class.forName("com.mysql.cj.jdbc.Driver");
				System.out.println("Driver class loaded");
				Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/kanishk","root","tiger");
				System.out.println("Connection is established with mysql");
				int choice=0;
				switch(choice)
				{
				case 1:
					PreparedStatement ps=con.prepareStatement("insert into stu value(?,?,?,?,?)");
				    int i=1;
				    while(i==1)
				    {
				    System.out.println("Enter Employee id : ");
				    int id=sc.nextInt();
				    System.out.println("Enter Employee name : ");
				    String name=sc.next();
				    System.out.println("Enter Employee address : ");
				    String ad=sc.next();
				    System.out.println("Enter Employee salary : ");
				    int sal=sc.nextInt();
				    System.out.println("Enter Employee department : ");
				    String dt=sc.next();
				    ps.setInt(1, id);
				    ps.setString(2,name);
				    ps.setString(3, ad);
				    ps.setInt(4, sal);
				    ps.setString(5, dt);
				    ps.execute();
				    System.out.println("record inserted");
				    System.out.println("Enter one more record 1.yes 0.no");
				    i=sc.nextInt();
				    }
				case 2:
					CallableStatement cs=con.prepareCall("call new_procedure1()");
					cs.execute();	
				}
				con.close();		
				System.out.println("Record Released");
			}
	}

