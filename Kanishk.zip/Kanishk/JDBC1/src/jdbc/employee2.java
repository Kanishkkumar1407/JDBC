package jdbc;
import java.util.*;
import java.sql.Connection;
import java.sql.*;
public class employee2 {

	public static void main(String[] args)throws Exception {
		// TODO Auto-generated method stub
        int id;

        Scanner vc =new Scanner(System.in);

        Class.forName("com.mysql.cj.jdbc.Driver");

        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/kanishk","root","tiger");

        Statement stmt = conn.createStatement();

        stmt.executeUpdate("create table IF NOT EXISTS employee(eid INT,ename varchar(50),salary INT,address varchar(100),dept varchar(10));");

        boolean loop=true;

        while(loop)

        {

            System.out.println("Enter 1 for add employee");

            System.out.println("Enter 2 for update salary");

            System.out.println("Enter 3 for remove employee");

            System.out.println("Enter 4 for all employee");

            int choice=vc.nextInt();

            switch (choice)

            {

                case 1:

                    System.out.println("Enter emp id:");

                    id=vc.nextInt();

                    System.out.println("Enter emp name:");

                    String name=vc.next();

                    System.out.println("Enter emp salary:");

                    int salary=vc.nextInt();

                    System.out.println("Enter emp address:");

                    String address=vc.next();

                    System.out.println("Enter emp dept:");

                    String dept=vc.next();

                    String create="insert into employee values('"+id+"','"+name+"','"+salary+"','"+address+"','"+dept+"');";

                    stmt.executeUpdate(create);

                    break;

                case 2:

                    System.out.println("Enter emp id:");

                    id=vc.nextInt();

                    stmt.executeUpdate("update employee SET salary = salary*1.1 where eid="+id+";");

                    break;

                case 3:

                    System.out.println("Enter emp id:");

                    id=vc.nextInt();

                    stmt.executeUpdate("delete from employee where eid="+id+";");

                    break;

                case 4:

                    ResultSet rs =  stmt.executeQuery("select *from employee");

                    System.out.println("EMPdetails:");

                    while(rs.next())

                    {

                        System.out.println("ID:"+rs.getInt(1)+" NAME:"+rs.getString(2)+" Salary:"+rs.getInt(3)+" address:"+rs.getString(4)+" DEPT:"+rs.getString(5));

                    }

                    break;

                default:

                    System.out.println("Enter number from 1-4.");

                    break;

            }

            System.out.println("Do you continue true/false");

            loop=vc.nextBoolean();

        }

    }

}