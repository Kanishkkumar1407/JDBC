package jdbc;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;

public class jdbcDemo3 {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/kanishk","root","tiger");
		System.out.println("Connection is established with mysql");
		CallableStatement cs=con.prepareCall("call new_procedure()");
		cs.execute();
		con.close();
		System.out.println("Connection Released");

	}

}
