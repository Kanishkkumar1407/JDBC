package jdbc;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.*;
public class jdbcdemo2 {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		Class.forName("com.mysql.cj.jdbc.Driver");
		System.out.println("Driver class loaded");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/kanishk","root","tiger");
		System.out.println("Connection is established with mysql");
		PreparedStatement ps=con.prepareStatement("insert into stu value(?,?,?,?)");
		int i=1;
		while(i==1)
		{
		System.out.println("Enter student id : ");
		int id=sc.nextInt();
		System.out.println("Enter student name : ");
		String name=sc.next();
		System.out.println("Enter student m1 : ");
		int m1=sc.nextInt();
		System.out.println("Enter student m2 : ");
		int m2=sc.nextInt();
		ps.setInt(1, id);
		ps.setString(2,name);
		ps.setInt(3, m1);
		ps.setInt(4, m2);
		ps.execute();
		System.out.println("record inserted");
		System.out.println("Enter one more record 1.yes 0.no");
		i=sc.nextInt();
		}
		con.close();		
		System.out.println("Record Released");
	}
}

