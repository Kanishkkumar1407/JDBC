package jdbc;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Connection;
import java.util.Scanner;
public class testpcc2 {
 public static void main(String[] args) throws Exception
 {
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/kanishk","root","tiger");
        int i=1;
        Scanner scanner = new Scanner(System.in);
        while (i == 1) 
        {
        System.out.println("Options:");
        System.out.println("1. Insert student data");
        System.out.println("2. Update");
        System.out.println("3. Delete student data");
        System.out.println("4. Grades");
        System.out.println("5. Display");
       System.out.print("Enter your choice (1/2/3/4/5): ");
       int choice = scanner.nextInt();
       switch (choice)
 {
 	case 1:
 			System.out.print("Enter student ID: ");
            int stdid = scanner.nextInt();
            System.out.print("Enter student name: ");
            String sname = scanner.next();
            System.out.print("Enter marks for subject 1: ");
            int m1 = (int)scanner.nextFloat();
            if(isValidMarks(m1))
            {
            	System.out.println("entered sucessfully");
            }
            else
            {
            	System.out.println("Invalid marks");
            }
            System.out.print("Enter marks for subject 2: ");
            
            int m2 = (int)scanner.nextFloat();
            if(isValidMarks(m2))
            {
            	System.out.println("Entered successfully");
            }
            else
            {
            	System.out.println("Invalid marks");
            }
           System.out.print("Enter marks for subject 3: ");
           int m3 = (int)scanner.nextFloat();
           if(isValidMarks(m3))
           {
           	System.out.println("Entered successfully");
           }
           else
           {
           	System.out.println("Invalid marks");
           }
            System.out.print("Enter marks for subject 4: ");
            
            int m4 = (int)scanner.nextFloat();
            if(isValidMarks(m4))
            {
            	System.out.println("Inserted successfully");
            }
            else
            {
            	System.out.println("Invalid marks");
            }
            System.out.print("Enter marks for subject 5: ");
            int m5 = (int)scanner.nextFloat();
            if(isValidMarks(m5))
            {
            	System.out.println("Inserted successfully");
            }
            else
            {
            	System.out.println("Invalid marks");
            }
            System.out.print("Enter marks for subject 6: ");
           int m6 = (int)scanner.nextFloat();
           if(isValidMarks(m6))
           {
           	System.out.println("Inserted successfully");
           }
           else
           {
           	System.out.println("Invalid marks");
           }
           //if (isValidMarks(m1) && isValidMarks(m2) && isValidMarks(m3) &&
           //    isValidMarks(m4) && isValidMarks(m5) && isValidMarks(m6)) {
            	PreparedStatement ps = con.prepareStatement("insert into student2 values(?,?,?,?,?,?,?,?)");
                ps.setInt(1, stdid);
                ps.setString(2, sname);
                ps.setInt(3, m1);
                ps.setInt(4, m2);
                ps.setInt(5, m3);
                ps.setInt(6, m4);
                ps.setInt(7, m5);
                ps.setInt(8, m6);
                ps.execute();
                System.out.println("Student data inserted successfully!");
           //} else {
            //   System.out.println("Invalid marks! Marks should be between 0 to 100 for all subjects.");
           
            break;
           case 2:
        	   System.out.println("Enter student id to update:");
				int sid=scanner.nextInt();
				System.out.println("Enter which subject number (1,2,3,4,5,6)should be updated");
				int sub=scanner.nextInt();
				System.out.println("Enter updated marks");
				int nm=scanner.nextInt();
				if(nm>=0&&nm<=100) {
				if (sub==1) {
					PreparedStatement p1=con.prepareStatement("update student2 set m1 =? where studentid=?");
					p1.setInt(1,nm);
					p1.setInt(2,sid);
					p1.executeUpdate();
				}
				if (sub==2) {
					PreparedStatement p1=con.prepareStatement("update student2 set m2 =? where studentid=?");
					p1.setInt(1,nm);
					p1.setInt(2,sid);			
					p1.executeUpdate();
				}
				if (sub==3) {
					PreparedStatement p1=con.prepareStatement("update student2 set m3 =? where studentid=?");
					p1.setInt(1,nm);
					p1.setInt(2,sid);
					p1.executeUpdate();
				}
				if (sub==5) {
					PreparedStatement p1=con.prepareStatement("update student2 set m5 =? where studentid=?");
					p1.setInt(1,nm);
					p1.setInt(2,sid);
					p1.executeUpdate();

				}
				if (sub==6) {
					PreparedStatement p1=con.prepareStatement("update student2 set m6 =? where studentid=?");
					p1.setInt(1,nm);
					p1.setInt(2,sid);
					p1.executeUpdate();
				}
				if (sub==4) {
					PreparedStatement p1=con.prepareStatement("update student2 set m4 =? where studentid=?");
					p1.setInt(1,nm);
					p1.setInt(2,sid);
					p1.executeUpdate();
				}

				}
				else {
					System.out.println("Marks should be 0 to 100");
				}
				System.out.println("Records Updated");
				break;
            case 3:
            	 System.out.print("Enter the student ID to delete: ");
                 int deleteStdId = scanner.nextInt();
                 PreparedStatement ps3 = con.prepareStatement("DELETE FROM student2 WHERE studentid=?");
                 ps3.setInt(1, deleteStdId);
                 ps3.execute();
                 System.out.println("Student data deleted successfully!");
                 break;
            
           case 4:
        	   PreparedStatement ps1 = con.prepareStatement("select * from student2 where studentid=?");
        	   System.out.println("Enter the student id");
        	   int D=scanner.nextInt();
        	   ps1.setInt(1, D);
        	   ResultSet rs=ps1.executeQuery();
            	while(rs.next())
            	{
            		int a1=rs.getInt("m1");
            		int a2=rs.getInt("m2");
            		int a3=rs.getInt("m3");
            		int a4=rs.getInt("m4");
            		int a5=rs.getInt("m5");
            		int a6=rs.getInt("m6");
            		if(a1>=90 && a1<=100)
            		{
            			System.out.println("Grade for m1 is O");
            		}
            		else if(a1>=80 && a1<=90)
            		{
            			System.out.println("Grade for m1 is A+");
            		}
            		else if(a1>=70 && a1<=80)
            		{
            			System.out.println("Grade for m1 is A");
            		}
            		else if(a1>=60 && a1<=70)
            		{
            			System.out.println("Grade for m1 is B+");
            		}
            		else if(a1>=50 && a1<=60)
            		{
            			System.out.println("Grade for m1 is B");
            		}
            		else 
            		{
            			System.out.println("You are failed in M1");
            		}
            		if(a2>=90 && a2<=100)
            		{
            			System.out.println("Grade for m2 is O");
            		}
            		else if(a2>=80 && a2<=90)
            		{
            			System.out.println("Grade for m2 is A+");
            		}
            		else if(a2>=70 && a2<=80)
            		{
            			System.out.println("Grade for m2 is A");
            		}
            		else if(a2>=60 && a2<=70) {
            			System.out.println("Grade for m2 is B+");
            		}
            		else if(a2>=50 && a2<=60) {
            			System.out.println("Grade for m2 is B");
            		}
            		else {
            			System.out.println("You are failed in M2");
            		}
            		if(a3>=90 && a3<=100) {
            			System.out.println("Grade for m3 is O");
            		}
            		else if(a3>=80 && a3<=90) {
            			System.out.println("Grade for m3 is A+");
            		}
            		else if(a3>=70 && a3<=80) {
            			System.out.println("Grade for m3 is A");
            		}
            		else if(a3>=60 && a3<=70) {
            			System.out.println("Grade for m3 is B+");
            		}
            		else if(a3>=50 && a3<=60) {
            			System.out.println("Grade for m3 is B");
            		}
            		else {

            			System.out.println("You are failed in M3");

            		}if(a4>=90 && a4<=100) {

            			System.out.println("Grade for m4 is O");

            		}
            		else if(a4>=80 && a4<=90) {
            			System.out.println("Grade for m4 is A+");
            		}
            		else if(a4>=70 && a4<=80) {
            			System.out.println("Grade for m4 is A");
            		}
            		else if(a4>=60 && a4<=70) {
            			System.out.println("Grade for m4 is B+");
            		}
            		else if(a4>=50 && a4<=60) {
            			System.out.println("Grade for m4 is B");
            		}
            		else {
            			System.out.println("You are failed in M4");
            		}
            		if(a5>=90 && a5<=100) {

            			System.out.println("Grade for m5 is O");
            		}
           		else if(a5>=80 && a5<=90) {
            			System.out.println("Grade for m5 is A+");
            		}
            		else if(a5>=70 && a5<=80) {

            			System.out.println("Grade for m5 is A");
            		}
           		else if(a5>=60 && a5<=70) {
            			System.out.println("Grade for m5 is B+");
            		}

            		else if(a5>=50 && a5<=60) {
            			System.out.println("Grade for m5 is B");
            		}
            		else {
            			System.out.println("You are failed in M5");
            		}

            		if(a6>=90 && a6<=100) {

            			System.out.println("Grade for m6 is O");
            		}
            		else if(a6>=80 && a6<=90) {
            			System.out.println("Grade for m6 is A+");
            		}
            		else if(a6>=70 && a6<=80) {
            			System.out.println("Grade for m6 is A");
            		}
            		else if(a6>=60 && a6<=70) {
            			System.out.println("Grade for m6 is B+");
            		}
            		else if(a6>=50 && a6<=60) {
            			System.out.println("Grade for m6 is B");
            		}
            		else {
            			System.out.println("You are failed in M6");
            		}
            		int result=(a1+a2+a3+a4+a5+a6)/6;
            		if(result>=90 && result<=100) {
            			System.out.println("Your overall grade is O");
            		}

            		else if(result>=80 && result<=90) {
            			System.out.println("Your overall grade is A+");
            		}
            		else if(result>=70 && result<=80) {
            			System.out.println("Your overall grade is A");

            		}
            		else if(result>=60 && result<=70) {
            			System.out.println("Your overall grade is B+");
            		}
            		else if(result>=50 && result<=60) {
            			System.out.println("Your overall grade is B");
            		}
            		else {
            			System.out.println("You are failed!!");
            		}
            	}
            	break;
           case 5:
				System.out.println("Enter student id that to be displayed");
				int rid = scanner.nextInt();
				PreparedStatement r = con.prepareStatement("select * from student2 where studentid=?");
				r.setInt(1, rid);
				ResultSet rs1 = r.executeQuery();
				while(rs1.next())
				{
					System.out.println("ID:"+rs1.getInt(1));
					System.out.println("Name:"+rs1.getString(2));
					System.out.println("Marks1:"+rs1.getInt(3));
					System.out.println("Marks2:"+rs1.getInt(4));
					System.out.println("Marks3:"+rs1.getInt(5));
					System.out.println("Marks4:"+rs1.getInt(6));
					System.out.println("Marks5:"+rs1.getInt(7));
					System.out.println("Marks6:"+rs1.getInt(8));
				}
				break;
            default:
                System.out.println("Invalid choice! Please choose a valid option.");
        }
    }
        con.close();
        }
    
   private static boolean isValidMarks(int marks) {

        return marks >= 0 && marks <= 100;

    }
}
