package collections;
import java.util.Collections;
import java.util.ArrayDeque;
public class ArrayDequeueDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayDeque ad=new ArrayDeque();
		ad.add(15);
		ad.add(36);
		ad.add(29);
		ad.add("kanishk");
		ad.push(231);
		System.out.println(ad);
		System.out.println(ad.removeLast());
		ad.addLast(143);
		System.out.println(ad);
	}

}
