package collections;
import java.util.ArrayList;
import java.util.Collections;
public class ArrayListDemo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList al = new ArrayList();
		al.add(10);
		al.add("anurag");
		al.add(20);
		al.add(12.5);
		al.add(10);
		al.remove("anurag");
		System.out.println(al);
	}

}
