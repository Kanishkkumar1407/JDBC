package collections;
import java.util.Collections;
import java.util.Stack;
public class Stackdemo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Stack<Integer> st=new Stack<Integer>();
		st.add(10);
		st.push(20);
		st.add(10);
		st.add(5);
		st.push(60);
		st.push(30);
		System.out.println(st);
		System.out.println("Removed element from the stack is "+st.pop());
		System.out.println("Top element from the stack is "+st.peek());
		System.out.println(st);
		Collections.sort(st);
		System.out.println(st);
	}
}
