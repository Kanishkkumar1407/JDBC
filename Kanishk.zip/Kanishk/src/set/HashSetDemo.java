package set;
import java.util.HashSet;
import java.util.TreeSet;
public class HashSetDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashSet<Integer> hs= new HashSet<Integer>();
		hs.add(29);
		hs.add(36);
		hs.add(29);
		hs.add(null);
		System.out.println(hs);
		TreeSet<Integer> ts= new TreeSet<Integer>();
		hs.add(29);
		hs.add(36);
		hs.add(29);
		hs.add(null);
		System.out.println(hs);
	}

}
