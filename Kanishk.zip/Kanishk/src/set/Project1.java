package set;
import java.util.ArrayList;
import java.util.HashSet;
public class Project1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Integer> al1= new ArrayList<Integer>();
		al1.add(29);
		al1.add(36);
		al1.add(29);
		al1.add(65);
		al1.add(15);
		al1.add(380);
		al1.add(19);
		al1.add(143);
		System.out.println(al1);
		al1.addAll(al1);
		System.out.println(al1);
		ArrayList<Integer> al2= new ArrayList<Integer>();
		al2.add(1029);
		al2.add(136);
		al2.add(219);
		al2.add(650);
		al2.add(150);
		al2.add(380);
		al2.add(1029);
		al2.add(143);
		HashSet<Integer> hs = new HashSet<Integer>();
		hs.addAll(al2);
		hs.addAll(al1);
		System.out.println(hs);
	}

}
